﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IQChampionsServiceLibrary
{
    public class AnswerResult
    {
        public bool Answer { get; set; }
        public DateTime Time { get; set; }

        public AnswerResult()
        {

        }
    }
}
